import React, { useState } from 'react'
import Select from 'react-select'

function Drop() {
  var colors=[
    {
        value:'l',
        label:"Lime"
     },
     {
        value:'la',
        label:"Lavender"
     },
     
    {
       value:"cri",
       label:"Crimson"
    },
    {
       value:"db",
       label:"Darkblue"
    },
    {
       value:'teal',
       label:"Teal"
    },
    {
       value:'rp',
       label:"RebeccaPurple"
    },
    {
        value:'gw',
        label:"GhostWhite"
     },
     {
        value:'aq',
        label:"AquaMarine"
     },
     
  ];
  var [setbgcolor,ddlvalue]=useState(colors.label);
  var ddlhandle = (e) => {
    ddlvalue(e.label);
  }
  return (
    <>
    <div className='head'>

    <h1>Color Changer</h1><hr></hr><br></br>
    </div>
    
      <div className='h'>
        <Select id='bar' options={colors} onChange={ddlhandle} >Choose the Color:
        </Select>
      </div>
          <h3> {setbgcolor}</h3>
        <div className='drop'>
            <style>{'.drop {background-color:'+setbgcolor+';}'}</style> 

        </div>
    </>
  )
}

export default Drop