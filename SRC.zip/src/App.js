
import './App.css';
import Drop from './new';



function App() {
  return (
     
    <Drop/>
  );
}

export default App;
